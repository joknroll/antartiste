A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/rOXrKp.

 

Forked from [Raphael Goetter](http://codepen.io/raphaelgoetter/)'s Pen [Simple Nav 1](http://codepen.io/raphaelgoetter/pen/XmXQNP/).